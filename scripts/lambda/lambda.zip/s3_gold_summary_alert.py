import os, json, boto3

SNS_TOPIC_ARN = os.getenv("SNS_TOPIC_ARN")

s3 = boto3.client("s3")
sns = boto3.client("sns")

def lambda_handler(event, context):
    # Triggered by S3 Put on gold_summary/...
    rec = event["Records"][0]
    bucket = rec["s3"]["bucket"]["name"]
    key = rec["s3"]["object"]["key"]

    # Read JSON summary
    obj = s3.get_object(Bucket=bucket, Key=key)
    body = obj["Body"].read().decode("utf-8").strip()
    data = json.loads(body) if body else []

    total = 0
    for item in data:
        total += int(item.get("anomaly_count", 0))

    msg = f"[IoT Anomaly] {total} anomalies detected in {bucket}/{key}"
    sns.publish(TopicArn=SNS_TOPIC_ARN, Subject="IoT Anomaly Alert", Message=msg)

    return {"status":"ok","anomalies":total}
